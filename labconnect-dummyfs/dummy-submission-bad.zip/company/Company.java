package company;

import java.util.ArrayList;

/**
 * A company class with employees that deliver packages between customers
 * 
 * @author Berkan Şahin
 * @version 08.03.2021
 */
public class Company implements Locatable {

    // Constants
    final static int EMPLOYEE_CAPACITY = 15;
    final static double MIN_WAGE = 2800;

    // Properties
    Employee[] employees;
    ArrayList<Customer> customers;
    int numOfEmployees;
    int employeeNo;
    int packageNo;
    int posX;
    int posY;

    // Constructor

    /**
     * Create a company placed on given location
     * 
     * @param x X coordinate of the company's location
     * @param y Y coordinate of the company's location
     */
    public Company(int x, int y) {
        posX = x;
        posY = y;
        employees = new Employee[EMPLOYEE_CAPACITY];
        customers = new ArrayList<>();
    }

    // Methods

    /**
     * Returns the X coordinate of the company's position
     * 
     * @return the X coordiante of the company's position
     */
    @Override
    public int getX() {
        return posX;
    }

    /**
     * Returns the Y coordinate of the company's position
     * 
     * @return the Y coordinate of the company's position
     */
    @Override
    public int getY() {
        return posY;
    }

    /**
     * Updates the location of the company
     * 
     * @param x The new X coordinate
     * @param y The new Y coordinate
     */
    @Override
    public void setPos(int x, int y) {
        posX = x;
        posY = y;
    }

    /**
     * Hires the given employee if the capacity isn't exceeded
     * 
     * @param candidate Employee to hire
     * @return {@code true} if the employee is hired, {@code false} otherwise
     */
    public boolean addEmployee(Employee candidate) {
        if (numOfEmployees == EMPLOYEE_CAPACITY) {
            return false;
        } else {
            candidate.adjustSalary(MIN_WAGE);
            candidate.setPos(posX, posY);
            employees[numOfEmployees] = candidate;
            numOfEmployees++;
            return true;
        }
    }

    /**
     * Add the given customer to the list of customers
     * 
     * @param customer Customer to add
     */
    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    /**
     * Terminate the contract of the employee at given index, if it exists
     * 
     * @param employeeIndex Index of the employee
     * @return {@code true} if there was an employee at index, otherwise
     *         {@code false}
     */
    public boolean terminateContract(int employeeIndex) {
        if (employees[employeeIndex] == null) {
            return false;
        } else {
            employees[employeeIndex] = null;

            // Swap employees around to fill the empty spot
            for (int i = employeeIndex + 1; i < numOfEmployees; i++) {
                Employee tmp = employees[i - 1];
                employees[i - 1] = employees[i];
                employees[i] = tmp;
            }

            numOfEmployees--;
            return true;
        }
    }

    /**
     * Assign the given item to an available employee for packaging and delivery
     * 
     * @param sendItem Item to send
     * @param sender   The customer that sent the item
     * @param receiver The customer that will receive the item
     * @return {@code true} if there's an employee available, otherwise
     *         {@code false}
     */
    public boolean createDeliverable(Item sendItem, Customer sender, Customer receiver) {
        for (int i = 0; i < numOfEmployees; i++) {
            if (employees[i].getAvailability()) {
                employees[i].addJob(sendItem, sender, receiver, packageNo);
                packageNo++;
                return true;
            }
        }

        return false;
    }

    /**
     * Delivers all the packages via Employees and prints
     * the delivery information.
     */
    public void deliverPackages() {
        for (int i = 0; i < numOfEmployees; i++) {
            employees[i].deliverPackages();
        }
    }

    /**
     * Provides information about the company, its customers and its employees
     * @return information about the company, customers and employees
     */
    @Override
    public String toString() {
        String result = String.format("[Company] Location: (%d, %d)%nCustomers:%n%n", posX, posY);

        for (Customer customer : customers) {
            result += customer + "\n";            
        }

        result += "\nEmployees:\n\n";

        for (int i = 0; i < numOfEmployees; i++) {
            result += employees[i] + "\n";
        }

        return result;
    }
}