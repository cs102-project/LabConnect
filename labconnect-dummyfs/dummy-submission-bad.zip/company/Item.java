package company;

/**
 * A class that creates an item that is not enclosed in a package
 * 
 * @author Berkan Şahin
 * @version 08.03.2021
 */
public class Item {
    
    // Properties
double weight;
    String content;

    // Constructors

    /**
     * Create a new item with given properties
     * @param weight Weight of the item
     * @param content Description of the content
     */
    public Item(double weight, String content) {
this.content = content;
        this.weight = weight;
    }

    // Methods

    /**
     * Returns a description of the content
     * @return a description of the content
     */
    public String getContent() {
        return content;
}

    /**
     * Returns the weight of the item
     * @return the weight of the item
     */
    public double getWeight() {
		        return weight;
    }

    /**
     * Returns the properties of the item
     * @return the properties of the item
     */
    @Override
    public String toString() {
        return "[Item] Content: " + content + ", Weight: " + weight;
    }
}
