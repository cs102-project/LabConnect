package company;

/**
 * A person that has a name and a location that is not fixed
 * 
 * @see Locatable
 * @author Berkan Şahin
 * @version 08.03.2021
 */
public abstract class Person implements Locatable {

    // Properties
    String name;
    int posX;
    int posY;

    // Constructors

    /**
     * Creates a person with the given name and position
     * @param name Name of the person
     * @param x X coordinate of the initial position
     * @param y Y coordinate of the initial position
     */
    public Person(String name, int x, int y) {
        this.name = name;
        posX = x;
        posY = y;
    }

    /**
     * Creates a person with the given name positioned at {@code 0,0}
     * @param name Name of the person
     */
    public Person(String name) {
        this(name, 0, 0);
    }

    // Methods

    /**
     * Returns the name of the person
     * @return the name of the person 
     */
    public String getName() {
        return name;
    }
    
    /**
     * Changes the name of the person
     * @param name The new name
     */
    public void setName(String name) {
        this.name = name;
    }


    /**
     * Returns the X coordinate of the current location
     * @return the X coordinate of the current location
     */
    @Override
    public int getX() {
        return posX;
    }

    /**
     * Returns the Y coordinate of the current location
     * @return the Y coordinate of the current location
     */
    @Override
    public int getY() {
        return posY;
    }

    /**
     * Update the position of the person
     * @param x The x coordiante of the new position
     * @param y The y coordinate of the new position
     */
    @Override
    public void setPos(int x, int y) {
        posX = x;
        posY = y;        
    }

}
