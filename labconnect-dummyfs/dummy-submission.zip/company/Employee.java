package company;

/**
 * A person that packages items and delivers said items and mail between
 * customers
 * 
 * @author Berkan Şahin
 * @version 08.03.2021
 */
public class Employee extends Person {

    // Constants
    final static int MAX_JOBS = 5;

    // Properties
    int currentJobs;
    int employeeNo;
    boolean available;
    double salary;
    Delivery[] deliveries;

    // Constructor

    /**
     * Creates an employee with given name and employee no.
     * 
     * @param employeeNo Employee number
     * @param name       Name of the employee
     */
    public Employee(int employeeNo, String name) {
        super(name);
        this.employeeNo = employeeNo;
        available = true;
        deliveries = new Delivery[MAX_JOBS];
    }

    // Methods

    /**
     * Increment the salary by given value
     * 
     * @param value The amonut to add
     */
    public void adjustSalary(double value) {
        salary = value;
    }

    /**
     * Check if the employee is available for a new job
     * 
     * @return {@code true} if the employee is available, otherwise {@false}
     */
    public boolean getAvailability() {
        return available;
    }

    /**
     * Packages given item based on its weight and adds it to the list of deliveries
     * 
     * @param sendItem  Item to deliver
     * @param sender    The customer sending the item
     * @param receiver  The customer receiving the item
     * @param packageNo Unique package no. given by the company
     */
    public void addJob(Item sendItem, Customer sender, Customer receiver, int packageNo) {
        if (getAvailability()) {
            Delivery packagedItem;

            if (sendItem.getWeight() <= 0.1) {
                packagedItem = new Mail(sendItem.getContent(), sender, receiver, packageNo);
            } else {
                packagedItem = new Package(sendItem, sender, receiver, packageNo);
            }

            deliveries[currentJobs] = packagedItem;
            currentJobs++;

            if (currentJobs == MAX_JOBS)
                available = false;
        }
    }

    /**
     * Prints information of all delivered items and clears deliveries
     */
    public void deliverPackages() {
        for (int i = 0; i < currentJobs; i++) {
            System.out.println(deliveries[i] + "\n");
        }

        deliveries = new Delivery[MAX_JOBS];
        currentJobs = 0;
        available = true;
    }

    /**
     * Provides information about the employee
     * 
     * @return properties of the Employee
     */
    @Override
    public String toString() {
        String result = String.format(
                "[Employee] Name: %s, Employee No: %d, Salary: %.2f%n" 
                + "Availability:%b, Location: (%d, %d)%nDeliveries:%n%n",
                name, employeeNo, salary, getAvailability(), posX, posY);

        for (int i = 0; i < currentJobs; i++) {
            result += deliveries[i] + "\n\n";
        }

        return result;
    }

}
