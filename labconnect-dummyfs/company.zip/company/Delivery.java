package company;

/**
 * A class that symbolizes a delivery
 * 
 * @author Berkan Şahin
 * @version 08.03.2021
 */
public abstract class Delivery {
    
    // Properties
    int packageNo;
    Customer sender;
    Customer receiver;

    // Constructors

    /**
     * Creates a new delivery between given customers and a packageNo for tracking
     * @param sender The customer sending the item
     * @param receiver The customer receiving the item
     * @param packageNo The ID that corresponds to the package
     */
    public Delivery(Customer sender, Customer receiver, int packageNo) {
        this.sender = sender;
        this.receiver = receiver;
        this.packageNo = packageNo;
    }

    // Methods

    /**
     * Returns the package number
     * @return the package number
     */
    public int getPackageNo() {
        return packageNo;
    }

    /**
     * Returns the receiving customer
     * @return the receiving customer
     */
    public Customer getReceiver() {
        return receiver;
    }

    /**
     * Returns the customer that sent the item
     * @return the customer that sent the item
     */
    public Customer getSender() {
        return sender;
    }

    /**
     * Returns the weight of the delivery
     * @return the weight of the delivery
     */
    public abstract double getWeight();
}
