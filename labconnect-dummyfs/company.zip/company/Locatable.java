package company;

/**
 * This interface requires any class that implements it to have a 
 * location in a two-dimensional grid that can be modified outside of the
 * class.
 * @author Berkan Şahin
 * @version 08.03.2021
 */
public interface Locatable {
    
    /**
     * Get the X coordinate of the Locatable
     * @return the current x coordinate
     */
    int getX();

    /**
     * Get the Y coordinate of the Locatable
     * @return the current y coordinate
     */
    int getY();

    /**
     * Set the position in the XY plane
     * @param x the new x coordinate
     * @param y the new y coordinate
     */
    void setPos(int x, int y);
}
