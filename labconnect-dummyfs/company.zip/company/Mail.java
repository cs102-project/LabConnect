package company;

/**
 * A delivery that doesn't need to be packaged, e.g. a letter
 * 
 * @author Berkan Şahin
 * @version 08.03.2021
 */
public class Mail extends Delivery {
    
    // Properties
    String content;

    // Constructor

    /**
     * Creates a mail from given content, customers and package number
     * @param content The content of the mail
     * @param sender The customer sending the mail
     * @param receiver The customer receiving the mail
     * @param packageNo A unique number for package identification
     */
    public Mail(String content, Customer sender, Customer receiver, int packageNo) {
        super(sender, receiver, packageNo);
        this.content = content;
    }

    // Methods

    /**
     * Returns the weight of the mail, which is fixed
     * @return the weight of the mail
     * @apiNote The weight is independent from the content and is always {@code 0.1}
     */
    @Override
    public double getWeight() {
        return 0.1;
    }

    /**
     * Returns information about the mail
     * @return information about the mail
     */
    @Override
    public String toString() {
        return String.format("[Mail] Package No: %d%nSender: %s%nReceiver: %s%nContent: %s", packageNo, sender, receiver, content);
    }

}
