package company;

/**
 * A Person that can send and receive items
 * 
 * @author Berkan Şahin
 * @version 08.03.2021
 */
public class Customer extends Person {

    // Properties
    Item currentItem;

    // Constructors

    public Customer(String name) {
        super(name);
    }

    // Methods

    /**
     * Returns the current item held by the customer
     * 
     * @return the current item
     */
    public Item getCurrentItem() {
        return currentItem;
    }

    /**
     * Replace the item held by the customer
     * 
     * @param newItem The new item
     */
    public void setCurrentItem(Item newItem) {
        currentItem = newItem;
    }

    /**
     * Send an item via given company to the receiver
     * <p>
     * The item parameter is ignored if the customer already holds an item
     * 
     * @param company  The company that will deliver the item
     * @param item     The item to be delivered, ignored if the customer already
     *                 holds an item
     * @param receiver The person that will receive the item
     * @return {@code true} if the company has an employee available for the job,
     *         otherwise {@code false}
     */
    public boolean sendItem(Company company, Item item, Customer receiver) {
        if (currentItem == null)
            return company.createDeliverable(item, this, receiver);
        else
            return company.createDeliverable(currentItem, this, receiver);
    }

    /**
     * Provides information about the customer
     * 
     * @return the properties of the customer
     */
    @Override
    public String toString() {
        return String.format("[Customer] Name: %s, Location: (%d, %d), Current Item: %s", name, posX, posY,
                currentItem);
    }

}