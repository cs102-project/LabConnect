package company;

/**
 * A package that encloses an item
 * 
 * @author Berkan Şahin
 * @version 08.03.2021
 */
public class Package extends Delivery {
   
    // Properties
    Item packedItem;

    // Constructor

    /**
     * Creates a package with a unique package no. that encloses a given item
     * @param content The item to pack
     * @param sender The customer sending the item
     * @param receiver The customer receiving the item
     * @param packageNo The unique package no. assigned by the company
     */
    public Package(Item content, Customer sender, Customer receiver, int packageNo) {
        super(sender, receiver, packageNo);
        packedItem = content;
    }

    // Methods

    /**
     * Returns the weight of the enclosed item
     * @return the weight of the enclosed item
     */
    @Override
    public double getWeight() {
        return packedItem.getWeight();
    }

    /**
     * Returns information about the package
     * @return information about the package
     */
    @Override
    public String toString() {
        return String.format("[Package] Package No: %d%nSender: %s%nReceiver: %s%nItem inside: %s", packageNo, sender, receiver, packedItem);
    }
}
