package shapes;

/**
 * A rectangle with integer center coordinates and dimensions
 * 
 * @version 26.02.2021
 * @author Berkan Şahin
 * @see Shape2D
 */
public class Rectangle extends Shape2D {

    // Properties
    int width;
    int height;

    /**
     * Creates a new rectangle with given center coordinates and dimensions
     * @param centerX X coordinate of the center point
     * @param centerY Y coordinate of the center point
     * @param width Width of the rectangle
     * @param height Lenght of the rectangle
     */
    public Rectangle(int centerX, int centerY, int width, int height) {
        super(centerX, centerY);
        this.width = width;
        this.height = height;
    }

    /**
     * Calculates the area of the rectangle
     * @return the area of the rectange
     */
    @Override
    public double calculateArea() {
        return width * height;
    }

    /**
     * Calculates the perimeter of the rectangle
     * @return the perimeter of the rectange
     */
    @Override
    public double calculatePerimeter() {
        return 2 * (width + height);
    }

    /**
     * Provides a String representation of this rectangle
     * @return Center coordinates and dimensions as string
     * @see Shape2D#toString()
     */
    @Override
    public String toString() {
        return String.format("[class Rectangle]%s, width=%d and height=%d", super.toString(), width, height);
    }

    /**
     * Checks if the given object is an equivalent rectangle
     * @param obj The object to compare
     * @return {@code true} if the given object is a {@link Rectangle} with the same dimensions
     * and center point, otherwise {@code false}
     */
    @Override
    public boolean equals(Object obj) {
        Rectangle otherRectangle;

        if (obj instanceof Rectangle) {
            otherRectangle = (Rectangle) obj;
            return super.equals(obj) && otherRectangle.width == width && otherRectangle.height == height;
        }
        else {
            return false;
        }
    }
}
