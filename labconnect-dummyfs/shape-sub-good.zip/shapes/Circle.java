package shapes;

import java.util.Locale;

/**
 * A circle with integer center coordinates and radius
 * 
 * @version 04.03.2021
 * @author Berkan Şahin
 * @see Shape2D
 */
public class Circle extends Shape2D {

    // Properties
    double radius;

    /**
     * Creates a circle with given center and radius
     * @param centerX X coordinate of the center
     * @param centerY Y coordinate of the center
     * @param radius Radius of the circle
     */
    public Circle(int centerX, int centerY, double radius) {
        super(centerX, centerY);
        this.radius = radius;
    }

    /**
     * Calculates the area of the circle
     * @return the area of the circle
     */
    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }    
    
    /**
     * Calculates the perimeter of the circle
     * @return the perimeter of the circle
     */
    @Override
    public double calculatePerimeter() {
        return 2 * Math.PI * radius;
    }

    /**
     * Provides a String representation of this circle
     * @return Center coordinates and radius as a string
     * @see Shape2D#toString()
     */
    @Override
    public String toString() {
        return String.format(Locale.US, "[class Circle]%s and radius=%.2f", super.toString(), radius);
    }

    /**
     * Checks if the given circle has the same center point and radius
     * @param obj The object to compare
     * @return {@code true} if the given object is a {@link Circle} with the same radius
     * and center point, otherwise {@code false}
     */
    @Override
    public boolean equals(Object obj) {
        Circle otherCircle;

        if (obj instanceof Circle) {
            otherCircle = (Circle) obj;
            return super.equals(obj) && otherCircle.radius == radius;
        }
        else {
            return false;
        }
    }

}
