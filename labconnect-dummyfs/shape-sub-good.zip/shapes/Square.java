package shapes;

/**
 * A square with integer center coordinates and side length
 * 
 * @version 26.02.2021
 * @author Berkan Şahin
 * @see Shape2D
 */
public class Square extends Shape2D {
    
    // Properties
    int sideLength;

    public Square(int centerX, int centerY, int sideLength) {
        super(centerX, centerY);
		this.sideLength = sideLength;
    }
    /**
     * Calculates the area of the square
     * @return the area of the square
     */
    @Override
    public double calculateArea() {
        return sideLength * sideLength;
    }

    /**
     * Calculates the perimeter of the square
     * @return the perimeter of the square
     */
    @Override
    public double calculatePerimeter() {
        return 4 * sideLength;
    }

    /**
     * Provides a String representation of this square
     * @return Center coordinates and side length as string
     * @see Shape2D#toString()
     */
    @Override
    public String toString() {
        return String.format("[class Square]%s and side=%d", super.toString(), sideLength);
    }

    /**
     * Checks if the given object is an equivalent square
     * @param obj The object to compare
     * @return {@code true} if the given object is a {@link Square} with the same side length
     * and center point, otherwise {@code false}
     */
    @Override
    public boolean equals(Object obj) {
        Square otherSquare;

        if (obj instanceof Square) {
            otherSquare = (Square) obj;
            return super.equals(obj) && otherSquare.sideLength == sideLength;
        }
        else {
            return false;
        }
    }

}
