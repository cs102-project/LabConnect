package shapes;

/**
 * A generic 2D shape class that contains the X and Y coordinates of the center
 * of the shape
 * 
 * @version 26.02.2021
 * @author Berkan Şahin
 */
public abstract class Shape2D {

    // Properties
    int centerX;
    int centerY;

    // Constructors

    /**
     * Creates a 2D shape with given center coordinates
     * @param centerX X coordinate of the center
     * @param centerY Y coordinate of the center
     */
    public Shape2D(int centerX, int centerY) {
        this.centerX = centerX;
        this.centerY = centerY;
    }

    // Methods

    /**
     * Calculates the perimeter of the shape
     * @return the perimeter of the shape
     */
    public abstract double calculatePerimeter();

    /**
     * Calculates the area of the shape
     * @return the area of the shape
     */
    public abstract double calculateArea();

    /**
     * Calculates the euclidean distance between the center points of two shapes
     * @param anyShape The shape to measure the distance of
     * @return the distance if the given object is a {@link Shape2D} instance,
     * otherwise {@code -1} 
     */
    public double calculateDistance(Object anyShape){
        int differenceX;
        int differenceY;
        Shape2D validatedShape;

        if (anyShape instanceof Shape2D) {
            validatedShape = (Shape2D) anyShape;
            differenceX = validatedShape.centerX - centerX;
            differenceY = validatedShape.centerY - centerY;
            return Math.sqrt(differenceX * differenceX + differenceY * differenceY);
        }
        else {
            return -1;
        }
    }

    /**
     * Provides a String representation of the center coordinates of the shape
     * @return The center coordinates in {@code (x, y)} format
     */
    @Override
    public String toString() {
        return String.format("x=%d, y=%d", centerX, centerY);
    }

    /**
     * Check if the given shapes have the same center coordinates
     * @param obj Object to compare
     * @return {@code true} if the given object is a {@link Shape2D} instance
     * and the center coordinates are equal, otherwise {@code false}
     */
    @Override
    public boolean equals(Object obj) {
        Shape2D otherShape;

        if (obj instanceof Shape2D) {
            otherShape = (Shape2D) obj;
            return otherShape.centerX == centerX && otherShape.centerY == centerY;            
        }
        else {
            return false;
        }
    }
}